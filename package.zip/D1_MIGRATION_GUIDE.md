# Kerkerker 迁移到 Cloudflare D1 数据库指南

## 📋 迁移概述

本指南将帮助您将 Kerkerker 项目从 SQLite 迁移到 Cloudflare D1 数据库。

## 🎯 迁移优势

### Cloudflare D1 特性
- **全球复制**: 数据在全球边缘节点复制
- **高可用性**: 99.99% SLA 保证
- **自动备份**: 内置备份和恢复机制
- **按需付费**: 基于查询次数计费
- **零运维**: 自动化管理，无需维护

### 性能提升
- **全球边缘**: 就近访问，延迟更低
- **智能缓存**: 智能数据缓存策略
- **弹性扩展**: 自动根据负载调整
- **安全隔离**: 企业级安全防护

## 🛠️ 迁移准备工作

### 1. 环境准备

确保您已安装并配置：
- Node.js >= 18
- npm 或 pnpm
- Wrangler CLI
- Git

### 2. 安装依赖

```bash
# 安装项目依赖
npm install

# 安装/更新 wrangler CLI
npm install -g wrangler
```

### 3. 配置 Cloudflare

```bash
# 登录 Cloudflare
wrangler login

# 验证登录状态
wrangler whoami
```

## 🚀 迁移步骤

### 步骤 1: 创建 D1 数据库

```bash
# 使用 D1 管理工具创建数据库
node scripts/d1-manager.js init

# 或者手动创建
wrangler d1 create kerkerker-db
```

### 步骤 2: 更新配置文件

配置文件会自动更新，包括：

1. **wrangler.toml** - 自动更新数据库 ID
2. **环境变量** - 更新数据库连接字符串
3. **Prisma 配置** - 确保 D1 兼容性

### 步骤 3: 迁移数据结构

```bash
# 运行数据库迁移
node scripts/d1-manager.js migrate

# 或者手动运行
wrangler d1 execute kerkerker-db --file=./prisma/migrations/20241115000000_init_kerkerker_db.sql
```

### 步骤 4: 初始化数据

```bash
# 填充测试数据
node scripts/d1-manager.js seed

# 验证数据创建
wrangler d1 console kerkerker-db
```

### 步骤 5: 更新应用配置

更新环境变量：

```bash
# 开发环境
DATABASE_URL="sqlite:./prisma/dev.db"

# 生产环境
DATABASE_URL="sqlite:./prisma/prod.db"
```

## 📊 数据模型说明

### 核心数据表

#### 用户管理
- **User**: 用户基本信息
- **Account**: OAuth 账户
- **Session**: 用户会话
- **VerificationToken**: 邮箱验证

#### 资源搜索
- **Resource**: 网盘资源信息
- **SearchHistory**: 搜索历史
- **Comment**: 用户评论
- **SearchLog**: 搜索日志

#### 系统管理
- **Setting**: 系统设置
- **ApiLog**: API 调用日志
- **CrawlerLog**: 爬虫运行日志
- **Statistic**: 统计数据
- **TelegramUpdate**: Telegram 机器人数据

### 数据关系

```
User 1:N Resource
Resource 1:N Comment
User 1:N SearchHistory
Resource 1:N SearchLog
User 1:N TelegramUpdate
```

## 🔧 管理工具使用

### D1 管理器命令

```bash
# 初始化数据库
node scripts/d1-manager.js init

# 填充测试数据
node scripts/d1-manager.js seed

# 备份数据库
node scripts/d1-manager.js backup

# 恢复数据库
node scripts/d1-manager.js restore ./backups/backup-2024-11-15.sql

# 查看数据库信息
node scripts/d1-manager.js info

# 打开控制台
node scripts/d1-manager.js console

# 重置数据库
node scripts/d1-manager.js reset
```

### 直接使用 wrangler

```bash
# 查看数据库信息
wrangler d1 info kerkerker-db

# 执行 SQL 命令
wrangler d1 execute kerkerker-db --command "SELECT COUNT(*) FROM User;"

# 导出数据库
wrangler d1 export kerkerker-db --output=backup.sql

# 导入数据库
wrangler d1 execute kerkerker-db --file=backup.sql

# 打开交互式控制台
wrangler d1 console kerkerker-db
```

## 📈 监控和维护

### 性能监控

1. **Cloudflare Dashboard**
   - 数据库性能指标
   - 查询执行时间
   - 存储使用情况

2. **日志监控**
   ```bash
   # 查看实时日志
   wrangler tail --filter="database"
   ```

### 备份策略

1. **自动备份**
   - D1 自动每日备份
   - 保留7天历史版本

2. **手动备份**
   ```bash
   # 定期备份
   node scripts/d1-manager.js backup
   
   # 部署前备份
   npm run db:backup
   ```

### 恢复策略

1. **灾难恢复**
   ```bash
   # 从备份恢复
   node scripts/d1-manager.js restore backup-file.sql
   ```

2. **回滚部署**
   - 使用 Cloudflare Dashboard 的回滚功能
   - 或重新部署到之前的版本

## 🎯 优化建议

### 数据库性能优化

1. **索引优化**
   - 已包含核心查询索引
   - 可根据查询模式添加额外索引

2. **查询优化**
   - 使用分页查询
   - 避免 N+1 查询问题
   - 合理使用连接查询

3. **缓存策略**
   ```javascript
   // 搜索结果缓存
   const searchCache = await redis.get(`search:${queryHash}`);
   if (searchCache) return JSON.parse(searchCache);
   ```

### 成本优化

1. **查询优化**
   - 减少不必要的复杂查询
   - 使用适当的分页
   - 避免大数据集传输

2. **监控使用量**
   - 定期检查查询次数
   - 监控存储空间使用
   - 设置告警阈值

## 🚨 故障排除

### 常见问题

1. **数据库连接失败**
   ```
   错误: database "kerkerker-db" not found
   解决: 确认数据库已创建，检查 wrangler.toml 配置
   ```

2. **权限不足**
   ```
   错误: Permission denied
   解决: 确保已登录 Cloudflare wrangler whoami
   ```

3. **迁移失败**
   ```
   错误: Migration failed
   解决: 检查 SQL 语法，确保数据库状态正确
   ```

4. **环境变量问题**
   ```
   错误: DATABASE_URL is not set
   解决: 检查 .env.local 和 wrangler.toml 配置
   ```

### 调试步骤

1. **验证配置**
   ```bash
   wrangler whoami
   wrangler d1 info kerkerker-db
   ```

2. **测试连接**
   ```bash
   wrangler d1 console kerkerker-db
   ```

3. **查看日志**
   ```bash
   wrangler tail --filter="database"
   ```

4. **重新初始化**
   ```bash
   node scripts/d1-manager.js reset
   ```

## 🔄 从 SQLite 迁移现有数据

### 如果您有现有的 SQLite 数据

1. **导出 SQLite 数据**
   ```bash
   # 复制现有数据库文件
   cp ./prisma/dev.db ./sqlite-backup.db
   
   # 使用 SQLite 工具导出
   sqlite3 sqlite-backup.db .dump > sqlite-export.sql
   ```

2. **转换数据格式**
   ```bash
   # 使用自定义脚本转换
   node scripts/migrate-sqlite-to-d1.js
   ```

3. **导入到 D1**
   ```bash
   # 转换后的文件导入到 D1
   wrangler d1 execute kerkerker-db --file=converted-data.sql
   ```

## 📚 相关资源

- [Cloudflare D1 官方文档](https://developers.cloudflare.com/d1/)
- [Wrangler CLI 文档](https://developers.cloudflare.com/workers/wrangler/)
- [Prisma D1 支持](https://www.prisma.io/docs/guides/database/integrations/cloudflare-d1)
- [Kerkerker GitHub 仓库](https://github.com/unilei/kerkerker)

## 🆘 技术支持

如果您在迁移过程中遇到问题：

1. **检查文档**: 查看相关技术文档
2. **检查日志**: 使用 `wrangler tail` 查看详细错误
3. **联系支持**: 在 GitHub 仓库提交 Issue
4. **社区支持**: 访问 Cloudflare 开发者社区

---

**🎉 迁移完成后，您的 Kerkerker 应用将享受 Cloudflare D1 的全球加速和高可用性！**