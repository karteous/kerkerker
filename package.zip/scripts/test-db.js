#!/usr/bin/env node

/**
 * 数据库连接测试工具
 * 用于验证 D1 数据库连接和配置
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

class DatabaseTester {
  constructor() {
    this.dbName = 'kerkerker-db';
    this.colors = {
      green: '\x1b[32m',
      red: '\x1b[31m',
      yellow: '\x1b[33m',
      blue: '\x1b[34m',
      reset: '\x1b[0m',
    };
  }

  log(message, color = 'reset') {
    console.log(`${this.colors[color]}${message}${this.colors.reset}`);
  }

  async testConnection() {
    this.log('🔍 开始测试数据库连接...', 'blue');
    
    try {
      // 测试 wrangler CLI
      await this.testWrangler();
      
      // 测试数据库连接
      await this.testDatabaseConnection();
      
      // 测试基本查询
      await this.testBasicQueries();
      
      this.log('✅ 所有测试通过！', 'green');
      
    } catch (error) {
      this.log(`❌ 测试失败: ${error.message}`, 'red');
      process.exit(1);
    }
  }

  async testWrangler() {
    this.log('📋 检查 wrangler CLI...', 'yellow');
    
    return new Promise((resolve, reject) => {
      const child = spawn('npx', ['wrangler', 'whoami'], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          this.log('✅ wrangler CLI 正常', 'green');
          resolve();
        } else {
          this.log('❌ wrangler CLI 配置错误', 'red');
          reject(new Error(error || 'wrangler CLI not working'));
        }
      });
    });
  }

  async testDatabaseConnection() {
    this.log('🗄️ 测试数据库连接...', 'yellow');
    
    return new Promise((resolve, reject) => {
      const child = spawn('npx', ['wrangler', 'd1', 'info', this.dbName], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          this.log('✅ D1 数据库连接正常', 'green');
          this.log(`📊 数据库信息: ${output}`, 'blue');
          resolve();
        } else {
          this.log('❌ D1 数据库连接失败', 'red');
          this.log(`错误信息: ${error}`, 'red');
          reject(new Error(error || 'Database connection failed'));
        }
      });
    });
  }

  async testBasicQueries() {
    this.log('🔍 测试基本查询...', 'yellow');
    
    // 测试查询用户表
    await this.runQuery('SELECT COUNT(*) as userCount FROM User;', '用户表');
    
    // 测试查询资源表
    await this.runQuery('SELECT COUNT(*) as resourceCount FROM Resource;', '资源表');
    
    // 测试查询设置表
    await this.runQuery('SELECT COUNT(*) as settingCount FROM Setting;', '设置表');
  }

  async runQuery(query, tableName) {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', [
        'wrangler', 
        'd1', 
        'execute', 
        this.dbName, 
        '--command', 
        query
      ], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(output.trim());
            const count = result[0]?.[Object.keys(result[0])[0]] || 0;
            this.log(`✅ ${tableName}: ${count} 条记录`, 'green');
            resolve();
          } catch (parseError) {
            this.log(`✅ ${tableName}: 查询成功`, 'green');
            resolve();
          }
        } else {
          this.log(`❌ ${tableName}: 查询失败`, 'red');
          this.log(`错误: ${error}`, 'red');
          reject(new Error(error));
        }
      });
    });
  }

  async testEnvironmentVariables() {
    this.log('🔧 检查环境变量...', 'blue');
    
    const requiredVars = [
      'DATABASE_URL',
      'NEXTAUTH_URL',
      'NEXTAUTH_SECRET',
      'NODE_ENV',
    ];
    
    for (const envVar of requiredVars) {
      const value = process.env[envVar];
      if (value) {
        this.log(`✅ ${envVar}: 已设置`, 'green');
      } else {
        this.log(`⚠️  ${envVar}: 未设置`, 'yellow');
      }
    }
  }

  async testConfigurationFiles() {
    this.log('📁 检查配置文件...', 'blue');
    
    const configFiles = [
      'wrangler.toml',
      'package.json',
      'prisma/schema.prisma',
      'prisma/migrations/20241115000000_init_kerkerker_db.sql',
    ];
    
    for (const file of configFiles) {
      const filePath = path.join(process.cwd(), file);
      if (fs.existsSync(filePath)) {
        this.log(`✅ ${file}: 存在`, 'green');
      } else {
        this.log(`❌ ${file}: 不存在`, 'red');
      }
    }
  }

  async runFullDiagnostic() {
    this.log('🏥 开始完整诊断...', 'blue');
    
    // 检查环境变量
    await this.testEnvironmentVariables();
    
    // 检查配置文件
    await this.testConfigurationFiles();
    
    // 检查数据库连接
    await this.testConnection();
    
    this.log('🎉 诊断完成！', 'green');
  }

  async interactiveConsole() {
    this.log('🖥️  打开交互式控制台...', 'blue');
    
    const child = spawn('npx', ['wrangler', 'd1', 'console', this.dbName], {
      stdio: 'inherit',
    });
    
    child.on('close', (code) => {
      this.log(`控制台已关闭 (代码: ${code})`, 'yellow');
    });
  }

  async quickHealthCheck() {
    try {
      // 简单健康检查
      const result = await this.runQuery('SELECT 1 as health_check;', '健康检查');
      this.log('✅ 数据库健康', 'green');
    } catch (error) {
      this.log('❌ 数据库不健康', 'red');
      process.exit(1);
    }
  }
}

// 主程序逻辑
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  const tester = new DatabaseTester();
  
  try {
    switch (command) {
      case 'connection':
        await tester.testConnection();
        break;
        
      case 'full':
        await tester.runFullDiagnostic();
        break;
        
      case 'console':
        await tester.interactiveConsole();
        break;
        
      case 'health':
        await tester.quickHealthCheck();
        break;
        
      default:
        console.log(`
🗄️  数据库测试工具

用法: node scripts/test-db.js [命令]

命令:
  connection    测试数据库连接
  full          完整诊断检查
  console       打开交互式控制台
  health        快速健康检查

示例:
  node scripts/test-db.js connection
  node scripts/test-db.js full
  node scripts/test-db.js health
        `);
        process.exit(0);
    }
    
  } catch (error) {
    console.error('💥 测试失败:', error.message);
    process.exit(1);
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  main();
}

module.exports = DatabaseTester;