#!/usr/bin/env node

/**
 * 自动数据库初始化脚本
 * 在应用启动时自动检查和初始化D1数据库
 */

import { D1Database } from '@cloudflare/workers-types';

// 默认配置
const DEFAULT_CONFIG = {
  // 应用配置
  appTitle: 'Kerkerker',
  appDescription: '网盘资源搜索神器',
  appVersion: '1.0.0',
  
  // 默认管理员
  defaultAdmin: {
    email: 'admin@kerkerker.com',
    password: 'admin123',
    name: '系统管理员'
  },
  
  // 默认分类
  defaultCategories: [
    { id: 'cat-1', name: '电影', slug: 'movies', description: '电影资源分类', icon: '🎬', color: '#FF6B6B', sortOrder: 1 },
    { id: 'cat-2', name: '音乐', slug: 'music', description: '音乐资源分类', icon: '🎵', color: '#4ECDC4', sortOrder: 2 },
    { id: 'cat-3', name: '软件', slug: 'software', description: '软件工具分类', icon: '💻', color: '#45B7D1', sortOrder: 3 },
    { id: 'cat-4', name: '游戏', slug: 'games', description: '游戏资源分类', icon: '🎮', color: '#96CEB4', sortOrder: 4 },
    { id: 'cat-5', name: '图书', slug: 'books', description: '图书文档分类', icon: '📚', color: '#FFEAA7', sortOrder: 5 }
  ],
  
  // 默认标签
  defaultTags: [
    { id: 'tag-1', name: '热门', slug: 'hot', color: '#FF6B6B' },
    { id: 'tag-2', name: '最新', slug: 'new', color: '#4ECDC4' },
    { id: 'tag-3', name: '高清', slug: 'hd', color: '#45B7D1' },
    { id: 'tag-4', name: '完整版', slug: 'complete', color: '#96CEB4' },
    { id: 'tag-5', name: '中文', slug: 'chinese', color: '#FFEAA7' }
  ],
  
  // 系统设置
  defaultSettings: [
    { key: 'site_name', value: 'Kerkerker', description: '网站名称', type: 'string' },
    { key: 'site_description', value: '网盘资源搜索神器', description: '网站描述', type: 'string' },
    { key: 'max_file_size', value: '100MB', description: '最大文件大小限制', type: 'string' },
    { key: 'enable_registration', value: 'true', description: '是否允许用户注册', type: 'boolean' },
    { key: 'maintenance_mode', value: 'false', description: '维护模式开关', type: 'boolean' }
  ]
};

// 数据库结构 SQL
const DATABASE_SCHEMA = `
-- ================================================
-- Kerkerker 数据库结构初始化
-- ================================================

-- 用户表
CREATE TABLE IF NOT EXISTS User (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  emailVerified TEXT,
  name TEXT,
  password TEXT,
  image TEXT,
  role TEXT DEFAULT 'user',
  isActive BOOLEAN DEFAULT true,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 账户表 (NextAuth)
CREATE TABLE IF NOT EXISTS Account (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL,
  type TEXT NOT NULL,
  provider TEXT NOT NULL,
  providerAccountId TEXT NOT NULL,
  refresh_token TEXT,
  access_token TEXT,
  expires_at INTEGER,
  token_type TEXT,
  scope TEXT,
  id_token TEXT,
  session_state TEXT,
  FOREIGN KEY (userId) REFERENCES User(id) ON DELETE CASCADE
);

-- 会话表 (NextAuth)
CREATE TABLE IF NOT EXISTS Session (
  id TEXT PRIMARY KEY,
  sessionToken TEXT UNIQUE NOT NULL,
  userId TEXT NOT NULL,
  expires DATETIME NOT NULL,
  FOREIGN KEY (userId) REFERENCES User(id) ON DELETE CASCADE
);

-- 验证令牌表 (NextAuth)
CREATE TABLE IF NOT EXISTS VerificationToken (
  identifier TEXT NOT NULL,
  token TEXT NOT NULL,
  expires DATETIME NOT NULL,
  PRIMARY KEY (identifier, token)
);

-- 资源表
CREATE TABLE IF NOT EXISTS Resource (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  url TEXT NOT NULL,
  categoryId TEXT,
  tags TEXT,
  fileSize TEXT,
  fileType TEXT,
  uploadTime DATETIME,
  downloads INTEGER DEFAULT 0,
  rating REAL DEFAULT 0,
  status TEXT DEFAULT 'active',
  isVerified BOOLEAN DEFAULT false,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (categoryId) REFERENCES Category(id)
);

-- 分类表
CREATE TABLE IF NOT EXISTS Category (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  icon TEXT,
  color TEXT,
  parentId TEXT,
  sortOrder INTEGER DEFAULT 0,
  isActive BOOLEAN DEFAULT true,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parentId) REFERENCES Category(id)
);

-- 标签表
CREATE TABLE IF NOT EXISTS Tag (
  id TEXT PRIMARY KEY,
  name TEXT UNIQUE NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  color TEXT,
  usageCount INTEGER DEFAULT 0,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 资源标签关联表
CREATE TABLE IF NOT EXISTS ResourceTag (
  resourceId TEXT NOT NULL,
  tagId TEXT NOT NULL,
  PRIMARY KEY (resourceId, tagId),
  FOREIGN KEY (resourceId) REFERENCES Resource(id) ON DELETE CASCADE,
  FOREIGN KEY (tagId) REFERENCES Tag(id) ON DELETE CASCADE
);

-- 评论表
CREATE TABLE IF NOT EXISTS Comment (
  id TEXT PRIMARY KEY,
  resourceId TEXT NOT NULL,
  userId TEXT NOT NULL,
  content TEXT NOT NULL,
  rating INTEGER CHECK (rating >= 1 AND rating <= 5),
  parentId TEXT,
  isApproved BOOLEAN DEFAULT false,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (resourceId) REFERENCES Resource(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES User(id) ON DELETE CASCADE,
  FOREIGN KEY (parentId) REFERENCES Comment(id)
);

-- 搜索历史表
CREATE TABLE IF NOT EXISTS SearchHistory (
  id TEXT PRIMARY KEY,
  userId TEXT,
  query TEXT NOT NULL,
  resultsCount INTEGER DEFAULT 0,
  filters TEXT,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES User(id) ON DELETE SET NULL
);

-- 系统设置表
CREATE TABLE IF NOT EXISTS Settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  description TEXT,
  type TEXT DEFAULT 'string',
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ================================================
-- 索引创建
-- ================================================

-- 用户表索引
CREATE INDEX IF NOT EXISTS idx_user_email ON User(email);
CREATE INDEX IF NOT EXISTS idx_user_role ON User(role);

-- 账户表索引
CREATE INDEX IF NOT EXISTS idx_account_userId ON Account(userId);
CREATE INDEX IF NOT EXISTS idx_account_provider ON Account(provider);

-- 会话表索引
CREATE INDEX IF NOT EXISTS idx_session_token ON Session(sessionToken);
CREATE INDEX IF NOT EXISTS idx_session_userId ON Session(userId);

-- 资源表索引
CREATE INDEX IF NOT EXISTS idx_resource_categoryId ON Resource(categoryId);
CREATE INDEX IF NOT EXISTS idx_resource_status ON Resource(status);
CREATE INDEX IF NOT EXISTS idx_resource_createdAt ON Resource(createdAt);
CREATE INDEX IF NOT EXISTS idx_resource_downloads ON Resource(downloads);
CREATE INDEX IF NOT EXISTS idx_resource_rating ON Resource(rating);
CREATE INDEX IF NOT EXISTS idx_resource_title ON Resource(title);

-- 分类表索引
CREATE INDEX IF NOT EXISTS idx_category_parentId ON Category(parentId);
CREATE INDEX IF NOT EXISTS idx_category_slug ON Category(slug);

-- 标签表索引
CREATE INDEX IF NOT EXISTS idx_tag_slug ON Tag(slug);
CREATE INDEX IF NOT EXISTS idx_tag_usageCount ON Tag(usageCount);

-- 评论表索引
CREATE INDEX IF NOT EXISTS idx_comment_resourceId ON Comment(resourceId);
CREATE INDEX IF NOT EXISTS idx_comment_userId ON Comment(userId);
CREATE INDEX IF NOT EXISTS idx_comment_createdAt ON Comment(createdAt);

-- 搜索历史表索引
CREATE INDEX IF NOT EXISTS idx_searchHistory_userId ON SearchHistory(userId);
CREATE INDEX IF NOT EXISTS idx_searchHistory_query ON SearchHistory(query);
CREATE INDEX IF NOT EXISTS idx_searchHistory_createdAt ON SearchHistory(createdAt);

-- 数据库版本控制表
CREATE TABLE IF NOT EXISTS _schema_version (
  version INTEGER PRIMARY KEY,
  applied_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`;

// 生成UUID
function generateId() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// 生成哈希密码 (简化版，生产环境应使用bcrypt)
function generateHash(password) {
  // 这里使用简单的哈希，生产环境应该使用bcrypt
  return btoa(password + 'kerkerker_salt');
}

// 检查数据库是否已初始化
async function checkDatabaseInitialized(db) {
  try {
    const result = await db.prepare('SELECT name FROM sqlite_master WHERE type="table" AND name="User"').first();
    return result !== null;
  } catch (error) {
    console.log('数据库检查失败:', error.message);
    return false;
  }
}

// 创建数据库结构
async function createDatabaseSchema(db) {
  console.log('🔄 正在创建数据库结构...');
  
  const statements = DATABASE_SCHEMA.split(';').filter(stmt => stmt.trim());
  
  for (const statement of statements) {
    if (statement.trim()) {
      try {
        await db.prepare(statement.trim()).run();
      } catch (error) {
        console.log('SQL执行警告:', error.message);
      }
    }
  }
  
  console.log('✅ 数据库结构创建完成');
}

// 插入初始数据
async function insertInitialData(db, config = DEFAULT_CONFIG) {
  console.log('🔄 正在插入初始数据...');
  
  try {
    // 插入分类数据
    for (const category of config.defaultCategories) {
      await db.prepare(`
        INSERT OR IGNORE INTO Category (id, name, slug, description, icon, color, sortOrder)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `).bind(
        category.id, category.name, category.slug, category.description,
        category.icon, category.color, category.sortOrder
      ).run();
    }
    
    // 插入标签数据
    for (const tag of config.defaultTags) {
      await db.prepare(`
        INSERT OR IGNORE INTO Tag (id, name, slug, color)
        VALUES (?, ?, ?, ?)
      `).bind(tag.id, tag.name, tag.slug, tag.color).run();
    }
    
    // 插入系统设置
    for (const setting of config.defaultSettings) {
      await db.prepare(`
        INSERT OR IGNORE INTO Settings (key, value, description, type)
        VALUES (?, ?, ?, ?)
      `).bind(setting.key, setting.value, setting.description, setting.type).run();
    }
    
    // 插入默认管理员
    const adminId = generateId();
    await db.prepare(`
      INSERT OR IGNORE INTO User (id, email, name, password, role, isActive)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(
      adminId,
      config.defaultAdmin.email,
      config.defaultAdmin.name,
      generateHash(config.defaultAdmin.password),
      'admin',
      true
    ).run();
    
    // 记录数据库版本
    await db.prepare(`
      INSERT OR IGNORE INTO _schema_version (version)
      VALUES (1)
    `).run();
    
    console.log('✅ 初始数据插入完成');
    console.log('📝 默认管理员账户:');
    console.log('   邮箱:', config.defaultAdmin.email);
    console.log('   密码:', config.defaultAdmin.password);
    
  } catch (error) {
    console.error('❌ 插入初始数据失败:', error.message);
    throw error;
  }
}

// 主初始化函数
async function initializeDatabase(db, config = DEFAULT_CONFIG) {
  console.log('🚀 开始初始化 Kerkerker 数据库...');
  
  try {
    // 检查数据库是否已初始化
    const isInitialized = await checkDatabaseInitialized(db);
    
    if (isInitialized) {
      console.log('✅ 数据库已初始化，跳过初始化步骤');
      return true;
    }
    
    // 创建数据库结构
    await createDatabaseSchema(db);
    
    // 插入初始数据
    await insertInitialData(db, config);
    
    console.log('🎉 数据库初始化完成！');
    return true;
    
  } catch (error) {
    console.error('❌ 数据库初始化失败:', error.message);
    return false;
  }
}

// 导出函数供其他模块使用
export {
  initializeDatabase,
  checkDatabaseInitialized,
  createDatabaseSchema,
  insertInitialData,
  DEFAULT_CONFIG,
  generateId,
  generateHash
};

// 如果直接运行此脚本
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('此脚本应在应用启动时自动运行');
  console.log('使用方法: import { initializeDatabase } from "./scripts/auto-init-db.js"');
}
