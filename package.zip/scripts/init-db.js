/**
 * 数据库初始化脚本
 * 用于在应用启动时确保数据库结构正确
 */

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

class DatabaseInitializer {
  constructor() {
    this.dbName = 'kerkerker-db';
    this.migrationsDir = path.join(process.cwd(), 'prisma', 'migrations');
  }

  async initialize() {
    console.log('🚀 开始初始化数据库...');
    
    try {
      // 1. 检查数据库是否存在
      const dbExists = await this.checkDatabaseExists();
      
      if (!dbExists) {
        console.log('📦 创建数据库...');
        await this.createDatabase();
      } else {
        console.log('✅ 数据库已存在');
      }

      // 2. 检查数据库结构
      const hasTables = await this.checkDatabaseStructure();
      
      if (!hasTables) {
        console.log('🔧 应用数据库结构...');
        await this.applyMigrations();
      } else {
        console.log('✅ 数据库结构完整');
      }

      // 3. 检查基础数据
      const hasBasicData = await this.checkBasicData();
      
      if (!hasBasicData) {
        console.log('🌱 初始化基础数据...');
        await this.seedDatabase();
      } else {
        console.log('✅ 基础数据完整');
      }

      console.log('🎉 数据库初始化完成！');
      
    } catch (error) {
      console.error('❌ 数据库初始化失败:', error.message);
      throw error;
    }
  }

  async checkDatabaseExists() {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', ['wrangler', 'd1', 'info', this.dbName], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          resolve(true);
        } else {
          resolve(false);
        }
      });
    });
  }

  async createDatabase() {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', ['wrangler', 'd1', 'create', this.dbName], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          console.log('✅ 数据库创建成功');
          
          // 提取数据库 ID 并更新配置
          const dbIdMatch = output.match(/Database ID: ([a-f0-9-]+)/);
          if (dbIdMatch) {
            const dbId = dbIdMatch[1];
            console.log(`📋 数据库 ID: ${dbId}`);
            
            // 更新 wrangler.toml
            this.updateWranglerConfig(dbId);
          }
          
          resolve();
        } else {
          reject(new Error(error || 'Database creation failed'));
        }
      });
    });
  }

  async checkDatabaseStructure() {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', [
        'wrangler', 
        'd1', 
        'execute', 
        this.dbName, 
        '--command', 
        'SELECT name FROM sqlite_master WHERE type="table" LIMIT 5;'
      ], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          try {
            const tables = JSON.parse(output.trim());
            resolve(tables.length > 0);
          } catch {
            resolve(false);
          }
        } else {
          resolve(false);
        }
      });
    });
  }

  async applyMigrations() {
    const migrations = fs.readdirSync(this.migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .sort();
    
    if (migrations.length === 0) {
      throw new Error('No migration files found');
    }
    
    for (const migration of migrations) {
      const migrationPath = path.join(this.migrationsDir, migration);
      console.log(`📝 应用迁移: ${migration}`);
      
      await this.executeMigration(migrationPath);
    }
  }

  async executeMigration(migrationFile) {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', [
        'wrangler', 
        'd1', 
        'execute', 
        this.dbName, 
        '--file', 
        migrationFile
      ], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          resolve();
        } else {
          reject(new Error(error || 'Migration failed'));
        }
      });
    });
  }

  async checkBasicData() {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', [
        'wrangler', 
        'd1', 
        'execute', 
        this.dbName, 
        '--command', 
        'SELECT COUNT(*) as count FROM Setting;'
      ], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          try {
            const result = JSON.parse(output.trim());
            const count = result[0]?.count || 0;
            resolve(count > 0);
          } catch {
            resolve(false);
          }
        } else {
          resolve(false);
        }
      });
    });
  }

  async seedDatabase() {
    return new Promise((resolve, reject) => {
      const child = spawn('node', ['scripts/seed.js'], {
        stdio: 'pipe',
      });
      
      let output = '';
      let error = '';
      
      child.stdout.on('data', (data) => {
        output += data.toString();
      });
      
      child.stderr.on('data', (data) => {
        error += data.toString();
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          console.log('✅ 基础数据初始化完成');
          resolve();
        } else {
          reject(new Error(error || 'Seeding failed'));
        }
      });
    });
  }

  updateWranglerConfig(dbId) {
    try {
      const wranglerPath = path.join(process.cwd(), 'wrangler.toml');
      
      if (fs.existsSync(wranglerPath)) {
        let content = fs.readFileSync(wranglerPath, 'utf8');
        
        // 更新数据库 ID
        content = content.replace(
          /database_id = "your-db-id"/,
          `database_id = "${dbId}"`
        );
        
        fs.writeFileSync(wranglerPath, content);
        console.log('📝 wrangler.toml 已更新');
      }
    } catch (error) {
      console.warn('⚠️  无法更新 wrangler.toml:', error.message);
    }
  }

  async runHealthCheck() {
    console.log('🏥 运行健康检查...');
    
    try {
      // 检查数据库连接
      const connectionTest = await this.runQuery('SELECT 1 as test;');
      
      if (connectionTest) {
        console.log('✅ 数据库连接正常');
      }
      
      // 检查表结构
      const tableTest = await this.runQuery('SELECT COUNT(*) as count FROM sqlite_master WHERE type="table";');
      
      if (tableTest) {
        console.log('✅ 数据库表结构正常');
      }
      
      console.log('🎉 健康检查通过！');
      
    } catch (error) {
      console.error('❌ 健康检查失败:', error.message);
      throw error;
    }
  }

  async runQuery(query) {
    return new Promise((resolve, reject) => {
      const child = spawn('npx', [
        'wrangler', 
        'd1', 
        'execute', 
        this.dbName, 
        '--command', 
        query
      ], {
        stdio: 'pipe',
      });
      
      child.on('close', (code) => {
        if (code === 0) {
          resolve(true);
        } else {
          resolve(false);
        }
      });
    });
  }
}

// 主程序逻辑
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  const initializer = new DatabaseInitializer();
  
  try {
    switch (command) {
      case 'init':
        await initializer.initialize();
        break;
        
      case 'health':
        await initializer.runHealthCheck();
        break;
        
      default:
        console.log(`
🗄️  数据库初始化工具

用法: node scripts/init-db.js [命令]

命令:
  init      初始化数据库 (创建+迁移+数据)
  health    运行健康检查

示例:
  node scripts/init-db.js init
  node scripts/init-db.js health
        `);
        process.exit(0);
    }
    
  } catch (error) {
    console.error('💥 操作失败:', error.message);
    process.exit(1);
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  main();
}

module.exports = DatabaseInitializer;