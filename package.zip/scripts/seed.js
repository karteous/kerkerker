const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('开始初始化数据库...');

  // 创建管理员用户
  const adminPassword = await bcrypt.hash('admin123456', 12);
  
  const admin = await prisma.user.upsert({
    where: { email: 'admin@kerkerker.com' },
    update: {},
    create: {
      email: 'admin@kerkerker.com',
      name: '管理员',
      password: adminPassword,
      role: 'admin',
    },
  });

  console.log('✅ 管理员用户创建成功:', admin.email);

  // 创建测试用户
  const testPassword = await bcrypt.hash('123456', 12);
  
  const testUser = await prisma.user.upsert({
    where: { email: 'user@example.com' },
    update: {},
    create: {
      email: 'user@example.com',
      name: '测试用户',
      password: testPassword,
      role: 'user',
    },
  });

  console.log('✅ 测试用户创建成功:', testUser.email);

  // 初始化系统设置
  const settings = [
    {
      key: 'site_name',
      value: 'Kerkerker 网盘资源搜索',
      description: '网站名称'
    },
    {
      key: 'site_description',
      value: '全网最全的网盘资源搜索引擎',
      description: '网站描述'
    },
    {
      key: 'admin_email',
      value: 'admin@kerkerker.com',
      description: '管理员邮箱'
    },
    {
      key: 'enable_registration',
      value: 'true',
      description: '是否允许用户注册'
    },
    {
      key: 'enable_comments',
      value: 'true',
      description: '是否启用评论功能'
    },
    {
      key: 'telegram_bot_token',
      value: '',
      description: 'Telegram 机器人令牌'
    },
    {
      key: 'http_proxy',
      value: '',
      description: 'HTTP 代理服务器'
    },
    {
      key: 'search_cache_ttl',
      value: '300',
      description: '搜索结果缓存时间（秒）'
    },
    {
      key: 'rate_limit_requests',
      value: '100',
      description: 'API 请求频率限制'
    },
    {
      key: 'enable_statistics',
      value: 'true',
      description: '是否启用统计分析'
    }
  ];

  for (const setting of settings) {
    await prisma.setting.upsert({
      where: { key: setting.key },
      update: {},
      create: setting,
    });
  }

  console.log('✅ 系统设置初始化完成');

  // 创建示例资源数据
  const sampleResources = [
    {
      title: 'Windows 11 专业版 ISO 镜像',
      description: '微软官方 Windows 11 专业版 64位 简体中文版',
      url: 'https://example.com/windows11-pro.iso',
      fileType: 'software',
      fileSize: '4.7GB',
      source: '蓝奏云',
      category: '系统软件',
      tags: ['Windows', '系统', '微软', '操作系统'],
      rating: 4.8,
    },
    {
      title: '复仇者联盟4：终局之战 4K蓝光原盘',
      description: '漫威电影宇宙经典之作，4K超高清画质，环绕音效',
      url: 'https://example.com/avengers-endgame-4k.mkv',
      fileType: 'video',
      fileSize: '68GB',
      source: '阿里云盘',
      category: '电影',
      tags: ['漫威', '复仇者联盟', '科幻', '动作', '4K'],
      rating: 4.9,
    },
    {
      title: 'Python编程：从入门到实践 第二版',
      description: '最新的Python编程入门教材，包含大量实例代码',
      url: 'https://example.com/python-programming-book.pdf',
      fileType: 'document',
      fileSize: '15MB',
      source: '百度网盘',
      category: '电子书',
      tags: ['Python', '编程', '教程', '编程入门'],
      rating: 4.7,
    },
    {
      title: '周杰伦专辑合集 (2000-2023)',
      description: '周杰伦全部专辑无损音质合集，包含歌词文件',
      url: 'https://example.com/jay-chou-collection.zip',
      fileType: 'audio',
      fileSize: '25GB',
      source: '123云盘',
      category: '音乐',
      tags: ['周杰伦', '华语流行', '无损音质', '专辑合集'],
      rating: 5.0,
    },
    {
      title: 'Adobe Creative Suite 2024 完整版',
      description: '包含Photoshop、Illustrator、Premiere Pro等完整套件',
      url: 'https://example.com/adobe-cs2024.zip',
      fileType: 'software',
      fileSize: '15GB',
      source: '蓝奏云',
      category: '办公软件',
      tags: ['Adobe', '设计', '视频编辑', '图形处理'],
      rating: 4.6,
    }
  ];

  for (const resource of sampleResources) {
    await prisma.resource.create({
      data: resource,
    });
  }

  console.log('✅ 示例资源数据创建完成');

  // 创建一些示例搜索历史
  await prisma.searchHistory.createMany({
    data: [
      {
        query: 'Python编程教程',
        results: 156,
        ip: '192.168.1.1',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
      {
        query: '复仇者联盟4',
        results: 89,
        ip: '192.168.1.2',
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
      },
      {
        query: 'Windows 11',
        results: 234,
        ip: '192.168.1.3',
        userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
      }
    ]
  });

  console.log('✅ 示例搜索历史创建完成');

  // 创建示例评论
  const firstResource = await prisma.resource.findFirst();
  if (firstResource) {
    await prisma.comment.create({
      data: {
        content: '非常好的资源，下载速度快，文件完整，推荐！',
        rating: 5,
        resourceId: firstResource.id,
        userId: testUser.id,
      }
    });
  }

  console.log('✅ 示例评论创建完成');

  // 创建示例爬虫日志
  await prisma.crawlerLog.createMany({
    data: [
      {
        source: '蓝奏云',
        url: 'https://www.lanzouw.com/sitemap.xml',
        status: 'success',
        records: 1250,
        duration: 30000,
      },
      {
        source: '阿里云盘',
        url: 'https://www.aliyundrive.com/api/open/stream/file/list',
        status: 'success',
        records: 892,
        duration: 25000,
      },
      {
        source: '百度网盘',
        url: 'https://pan.baidu.com/api/list',
        status: 'success',
        records: 1567,
        duration: 45000,
      }
    ]
  });

  console.log('✅ 示例爬虫日志创建完成');

  // 创建示例统计数据
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  await prisma.statistic.createMany({
    data: [
      {
        key: 'daily_search_count',
        value: '1234',
        metric: 'count',
        date: today,
      },
      {
        key: 'daily_search_count',
        value: '1156',
        metric: 'count',
        date: yesterday,
      },
      {
        key: 'total_resources',
        value: '15432',
        metric: 'count',
        date: today,
      },
      {
        key: 'source_distribution',
        value: '{"蓝奏云": 35, "阿里云盘": 28, "百度网盘": 22, "123云盘": 15}',
        metric: 'distribution',
        date: today,
      }
    ]
  });

  console.log('✅ 示例统计数据创建完成');

  console.log('\n🎉 数据库初始化完成！');
  console.log('📊 管理员登录信息:');
  console.log('   邮箱: admin@kerkerker.com');
  console.log('   密码: admin123456');
  console.log('\n📊 测试用户登录信息:');
  console.log('   邮箱: user@example.com');
  console.log('   密码: 123456');
}

main()
  .catch((e) => {
    console.error('❌ 数据库初始化失败:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });