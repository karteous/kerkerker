#!/usr/bin/env node

/**
 * Cloudflare D1 数据库管理工具
 * 
 * 用法:
 * node scripts/d1-manager.js [command] [options]
 * 
 * 命令:
 *   init          - 初始化数据库结构
 *   seed          - 填充测试数据
 *   backup        - 备份数据库
 *   restore       - 恢复数据库
 *   console       - 打开 D1 控制台
 *   info          - 显示数据库信息
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

class D1Manager {
  constructor() {
    this.dbName = 'kerkerker-db';
    this.migrationsDir = path.join(__dirname, '..', 'prisma', 'migrations');
    this.backupDir = path.join(__dirname, '..', 'backups');
  }

  async runCommand(command, description = '') {
    return new Promise((resolve, reject) => {
      console.log(`🔄 ${description || command}`);
      
      exec(command, (error, stdout, stderr) => {
        if (error) {
          console.error(`❌ 命令执行失败: ${stderr}`);
          reject(error);
        } else {
          console.log(`✅ ${description || command} 完成`);
          resolve(stdout);
        }
      });
    });
  }

  async init() {
    console.log('🚀 开始初始化 Cloudflare D1 数据库...');
    
    try {
      // 1. 确保备份目录存在
      if (!fs.existsSync(this.backupDir)) {
        fs.mkdirSync(this.backupDir, { recursive: true });
      }

      // 2. 创建 D1 数据库
      console.log('📦 创建 D1 数据库...');
      await this.runCommand(
        `wrangler d1 create ${this.dbName}`,
        '创建 D1 数据库'
      );

      // 3. 获取数据库 ID 并更新配置文件
      const output = await this.runCommand(
        `wrangler d1 info ${this.dbName}`,
        '获取数据库信息'
      );
      
      // 提取数据库 ID (简化处理，实际使用中可能需要解析输出)
      const dbId = output.match(/Database ID: ([a-f0-9-]+)/)?.[1];
      
      if (dbId) {
        console.log(`📋 数据库 ID: ${dbId}`);
        
        // 更新 wrangler.toml 中的数据库 ID
        const wranglerPath = path.join(__dirname, '..', 'wrangler.toml');
        let wranglerContent = fs.readFileSync(wranglerPath, 'utf8');
        wranglerContent = wranglerContent.replace(
          /database_id = "your-db-id"/,
          `database_id = "${dbId}"`
        );
        fs.writeFileSync(wranglerPath, wranglerContent);
        
        console.log('📝 wrangler.toml 已更新');
      }

      // 4. 运行数据库迁移
      const latestMigration = this.getLatestMigration();
      if (latestMigration) {
        await this.runCommand(
          `wrangler d1 execute ${this.dbName} --file=${latestMigration}`,
          '运行数据库迁移'
        );
      }

      // 5. 填充测试数据
      await this.seed();

      console.log('🎉 D1 数据库初始化完成！');
      
    } catch (error) {
      console.error('❌ D1 数据库初始化失败:', error.message);
      throw error;
    }
  }

  async seed() {
    console.log('🌱 开始填充测试数据...');
    
    try {
      // 生成 Prisma 客户端
      await this.runCommand('npm run db:generate', '生成 Prisma 客户端');
      
      // 运行种子脚本
      await this.runCommand('node scripts/seed.js', '运行数据库种子脚本');
      
      console.log('✅ 测试数据填充完成！');
      
    } catch (error) {
      console.error('❌ 测试数据填充失败:', error.message);
      throw error;
    }
  }

  async backup() {
    console.log('💾 开始备份数据库...');
    
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupFile = path.join(this.backupDir, `backup-${timestamp}.sql`);
      
      await this.runCommand(
        `wrangler d1 export ${this.dbName} --output=${backupFile}`,
        '导出数据库'
      );
      
      console.log(`📁 备份文件已保存到: ${backupFile}`);
      
    } catch (error) {
      console.error('❌ 数据库备份失败:', error.message);
      throw error;
    }
  }

  async restore(backupFile) {
    if (!backupFile) {
      console.error('❌ 请指定备份文件路径');
      process.exit(1);
    }
    
    console.log(`🔄 开始恢复数据库 from ${backupFile}...`);
    
    try {
      // 确认操作
      const readline = require('readline');
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
      });
      
      const answer = await new Promise((resolve) => {
        rl.question('⚠️  这将覆盖现有数据，确定要继续吗? (y/N): ', resolve);
      });
      
      rl.close();
      
      if (answer.toLowerCase() !== 'y') {
        console.log('❌ 操作已取消');
        return;
      }
      
      await this.runCommand(
        `wrangler d1 execute ${this.dbName} --file=${backupFile}`,
        '恢复数据库'
      );
      
      console.log('✅ 数据库恢复完成！');
      
    } catch (error) {
      console.error('❌ 数据库恢复失败:', error.message);
      throw error;
    }
  }

  async console() {
    console.log('🖥️  打开 D1 数据库控制台...');
    
    try {
      await this.runCommand(
        `wrangler d1 console ${this.dbName}`,
        '打开 D1 控制台'
      );
    } catch (error) {
      console.error('❌ 无法打开 D1 控制台:', error.message);
    }
  }

  async info() {
    console.log('📊 获取数据库信息...');
    
    try {
      const output = await this.runCommand(
        `wrangler d1 info ${this.dbName}`,
        '获取数据库信息'
      );
      
      console.log(output);
      
    } catch (error) {
      console.error('❌ 无法获取数据库信息:', error.message);
    }
  }

  getLatestMigration() {
    if (!fs.existsSync(this.migrationsDir)) {
      return null;
    }
    
    const migrations = fs.readdirSync(this.migrationsDir)
      .filter(file => file.endsWith('.sql'))
      .sort()
      .reverse();
    
    return migrations.length > 0 
      ? path.join(this.migrationsDir, migrations[0])
      : null;
  }

  async reset() {
    console.log('🗑️  重置数据库...');
    
    try {
      const readline = require('readline');
      const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
      });
      
      const answer = await new Promise((resolve) => {
        rl.question('⚠️  这将删除所有数据，确定要继续吗? (y/N): ', resolve);
      });
      
      rl.close();
      
      if (answer.toLowerCase() !== 'y') {
        console.log('❌ 操作已取消');
        return;
      }
      
      // 删除数据库
      await this.runCommand(
        `wrangler d1 delete ${this.dbName}`,
        '删除现有数据库'
      );
      
      // 重新初始化
      await this.init();
      
      console.log('✅ 数据库重置完成！');
      
    } catch (error) {
      console.error('❌ 数据库重置失败:', error.message);
      throw error;
    }
  }
}

// 主程序逻辑
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const options = args.slice(1);
  
  const manager = new D1Manager();
  
  try {
    switch (command) {
      case 'init':
        await manager.init();
        break;
        
      case 'seed':
        await manager.seed();
        break;
        
      case 'backup':
        await manager.backup();
        break;
        
      case 'restore':
        await manager.restore(options[0]);
        break;
        
      case 'console':
        await manager.console();
        break;
        
      case 'info':
        await manager.info();
        break;
        
      case 'reset':
        await manager.reset();
        break;
        
      case 'migrate':
        const migration = options[0];
        if (migration) {
          await manager.runCommand(
            `wrangler d1 execute ${manager.dbName} --file=${migration}`,
            '运行迁移文件'
          );
        } else {
          const latestMigration = manager.getLatestMigration();
          if (latestMigration) {
            await manager.runCommand(
              `wrangler d1 execute ${manager.dbName} --file=${latestMigration}`,
              '运行最新迁移'
            );
          } else {
            console.log('❌ 未找到迁移文件');
          }
        }
        break;
        
      default:
        console.log(`
🗄️  Cloudflare D1 数据库管理工具

用法: node scripts/d1-manager.js [命令] [选项]

命令:
  init              初始化数据库 (创建数据库 + 迁移 + 种子数据)
  seed              仅填充测试数据
  backup            备份数据库
  restore <file>    从备份文件恢复数据库
  console           打开 D1 控制台
  info              显示数据库信息
  reset             重置数据库 (删除 + 重新创建)
  migrate [file]    运行迁移文件 (默认最新)

示例:
  node scripts/d1-manager.js init
  node scripts/d1-manager.js backup
  node scripts/d1-manager.js restore ./backups/backup-2024-11-15.sql
  node scripts/d1-manager.js migrate prisma/migrations/20241115000000_init.sql
        `);
        process.exit(0);
    }
    
  } catch (error) {
    console.error('💥 操作失败:', error.message);
    process.exit(1);
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  main();
}

module.exports = D1Manager;