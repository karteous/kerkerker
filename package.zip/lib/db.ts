import { PrismaClient } from '@prisma/client';

// 全局变量，确保在开发环境中不会重复创建实例
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['query', 'info', 'warn', 'error'],
    // 在开发环境中记录所有查询
    ...(process.env.NODE_ENV === 'development' && {
      log: ['query', 'info', 'warn', 'error'],
    }),
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;

// 数据库连接测试
export async function testDatabaseConnection() {
  try {
    console.log('🔍 测试数据库连接...');
    
    // 测试基本查询
    const result = await prisma.$queryRaw`SELECT 1 as test`;
    
    if (Array.isArray(result) && result.length > 0) {
      console.log('✅ 数据库连接成功');
      return true;
    } else {
      console.error('❌ 数据库连接测试失败');
      return false;
    }
  } catch (error) {
    console.error('❌ 数据库连接失败:', error);
    return false;
  }
}

// 获取数据库统计信息
export async function getDatabaseStats() {
  try {
    const stats = await Promise.all([
      // 用户数量
      prisma.user.count(),
      // 资源数量
      prisma.resource.count(),
      // 评论数量
      prisma.comment.count(),
      // 搜索历史数量
      prisma.searchHistory.count(),
      // 系统设置数量
      prisma.setting.count(),
    ]);

    return {
      users: stats[0],
      resources: stats[1],
      comments: stats[2],
      searchHistory: stats[3],
      settings: stats[4],
    };
  } catch (error) {
    console.error('❌ 获取数据库统计失败:', error);
    return null;
  }
}

// 健康检查函数
export async function healthCheck() {
  try {
    // 测试数据库连接
    const dbConnected = await testDatabaseConnection();
    
    // 获取基本统计
    const stats = await getDatabaseStats();
    
    return {
      status: dbConnected ? 'healthy' : 'unhealthy',
      database: {
        connected: dbConnected,
        stats: stats || {},
      },
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version || '1.0.0',
    };
  } catch (error) {
    return {
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString(),
    };
  }
}

// 优雅关闭数据库连接
export async function disconnectDatabase() {
  try {
    console.log('🔌 关闭数据库连接...');
    await prisma.$disconnect();
    console.log('✅ 数据库连接已关闭');
  } catch (error) {
    console.error('❌ 关闭数据库连接时出错:', error);
  }
}

// 处理进程退出时的清理
process.on('SIGINT', async () => {
  await disconnectDatabase();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  await disconnectDatabase();
  process.exit(0);
});

// 默认导出 prisma 客户端实例
export default prisma;