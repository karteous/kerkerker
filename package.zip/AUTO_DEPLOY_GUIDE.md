# 🚀 Kerkerker 自动化部署指南

## 简化部署流程

您只需要设置 **3个核心环境变量**，其余所有配置都会自动内置！

### 1️⃣ 在 Cloudflare Dashboard 中设置环境变量

#### 进入 Cloudflare Pages 项目设置：
1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com)
2. 选择您的 Pages 项目
3. 点击 **Settings** → **Environment variables**

#### 添加必需的环境变量（仅需3个）：

```bash
# ✅ NEXTAUTH_SECRET - 认证密钥
NEXTAUTH_SECRET=your-32-character-random-secret

# ✅ ADMIN_EMAIL - 管理员邮箱
ADMIN_EMAIL=admin@your-domain.com

# ✅ ADMIN_PASSWORD - 管理员密码
ADMIN_PASSWORD=your-secure-password
```

#### 🔧 自动获取密钥的工具：

**生成 NEXTAUTH_SECRET：**
访问 https://www.grc.com/passwords.htm 获得64位随机密码

或使用此在线工具：https://generate-secret.vercel.app/32

### 2️⃣ 创建和绑定 D1 数据库

#### 在 Cloudflare Dashboard 中：
1. 进入 **D1 SQL Database**
2. 点击 **Create database**
3. 数据库名称: `kerkerker-db`
4. 记录数据库 ID

#### 在 Pages 项目中绑定 D1：
1. 项目设置 → **Functions** → **D1 Database Bindings**
2. 点击 **Add binding**:
   - **Variable name**: `DATABASE`
   - **Database**: `kerkerker-db`
   - **Environment**: `Production` 和 `Preview`

### 3️⃣ 触发自动初始化

#### 方法A: 访问应用首页
首次访问您的应用时，系统会自动检测并初始化数据库

#### 方法B: 手动触发初始化
访问: `https://your-domain.pages.dev/api/init-db`

**注意**: 首次访问需要几秒钟来完成数据库初始化

### 4️⃣ 验证部署

#### 健康检查
访问: `https://your-domain.pages.dev/api/health`

#### 管理员登录
- 邮箱: 您设置的 ADMIN_EMAIL
- 密码: 您设置的 ADMIN_PASSWORD

## 🎯 部署完成！

### 自动完成的功能：
- ✅ 数据库结构创建
- ✅ 初始数据插入
- ✅ 默认管理员账户
- ✅ 基础分类和标签
- ✅ 系统设置配置

### 默认设置：
- **网站名称**: Kerkerker
- **网站描述**: 网盘资源搜索神器
- **默认分类**: 电影、音乐、软件、游戏、图书
- **默认标签**: 热门、最新、高清、完整版、中文

## 🔧 自定义配置

如果需要修改默认设置，可以：

### 1. 修改内置配置
编辑 `scripts/auto-init-db.js` 文件中的 `DEFAULT_CONFIG` 对象

### 2. 通过 API 修改设置
```bash
# 修改网站名称
curl -X POST https://your-domain.pages.dev/api/settings \
  -H "Content-Type: application/json" \
  -d '{"key":"site_name","value":"我的网站"}'
```

## 📊 监控和维护

### 数据库监控
- 在 Cloudflare Dashboard → D1 → Analytics
- 查看查询次数、响应时间、存储使用量

### 应用监控
- 在 Pages 项目 → Analytics
- 查看访问统计、错误日志

### 日志查看
- Pages 项目 → Functions → Logs
- 查看应用运行日志

## 🚨 故障排除

### 数据库初始化失败
1. 检查 D1 数据库是否正确绑定
2. 确认环境变量设置正确
3. 查看 Functions 日志获取详细错误信息

### 应用无法访问
1. 检查环境变量 `NEXTAUTH_URL` 是否正确
2. 确认构建和部署成功
3. 查看 Pages 项目的构建日志

### 登录问题
1. 确认管理员邮箱和密码设置正确
2. 检查数据库是否成功初始化
3. 访问 `/api/health` 检查数据库状态

## 📞 支持

如果遇到问题：
1. 首先查看 `/api/health` 端点的返回信息
2. 检查 Cloudflare Dashboard 中的日志
3. 确认所有必需的环境变量都已设置

---

🎉 **恭喜！您的 Kerkerker 应用现在已经完全自动化部署，无需手动数据库操作！**
