/**
 * 数据库初始化 API 端点
 * 用于触发数据库初始化 (仅在开发环境或首次访问时使用)
 */

import { initializeDatabaseConnection, healthCheck } from '../../../lib/init-db.js';

export async function POST(request) {
  try {
    // 检查是否是授权请求 (简单验证)
    const authHeader = request.headers.get('authorization');
    const isAuthorized = !authHeader || authHeader === `Bearer ${process.env.ADMIN_PASSWORD}`;
    
    if (!isAuthorized) {
      return new Response(JSON.stringify({
        error: 'Unauthorized',
        message: '需要管理员权限'
      }), {
        status: 401,
        headers: {
          'Content-Type': 'application/json',
        },
      });
    }
    
    console.log('🔄 开始初始化数据库...');
    
    // 初始化数据库
    const success = await initializeDatabaseConnection();
    
    if (success) {
      const health = await healthCheck();
      
      return new Response(JSON.stringify({
        success: true,
        message: '数据库初始化成功',
        health: health,
        timestamp: new Date().toISOString()
      }), {
        status: 200,
        headers: {
          'Content-Type': 'application/json',
        },
      });
    } else {
      return new Response(JSON.stringify({
        success: false,
        error: '数据库初始化失败',
        timestamp: new Date().toISOString()
      }), {
        status: 500,
        headers: {
          'Content-Type': 'application/json',
        },
      });
    }
    
  } catch (error) {
    console.error('数据库初始化API错误:', error);
    
    return new Response(JSON.stringify({
      success: false,
      error: error.message,
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }
}

// 支持 OPTIONS 请求 (CORS)
export async function OPTIONS(request) {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}
