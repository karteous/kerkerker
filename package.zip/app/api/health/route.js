/**
 * 健康检查 API 端点
 * 用于检查应用和数据库状态
 */

import { healthCheck } from '../../../lib/init-db.js';

export async function GET(request) {
  try {
    // 执行健康检查
    const health = await healthCheck();
    
    // 检查数据库状态
    const dbStatus = health.initialized ? 'healthy' : 'initializing';
    
    const response = {
      status: health.status,
      timestamp: new Date().toISOString(),
      version: process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      database: {
        status: dbStatus,
        connected: health.database === 'connected',
        tables: health.tables || 0
      },
      services: {
        nextAuth: 'healthy',
        api: 'healthy'
      }
    };
    
    const statusCode = health.status === 'healthy' ? 200 : 503;
    
    return new Response(JSON.stringify(response), {
      status: statusCode,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache',
      },
    });
    
  } catch (error) {
    console.error('健康检查错误:', error);
    
    return new Response(JSON.stringify({
      status: 'error',
      timestamp: new Date().toISOString(),
      error: error.message,
      database: {
        status: 'error',
        connected: false,
        tables: 0
      }
    }), {
      status: 503,
      headers: {
        'Content-Type': 'application/json',
      },
    });
  }
}

// 支持 OPTIONS 请求 (CORS)
export async function OPTIONS(request) {
  return new Response(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
