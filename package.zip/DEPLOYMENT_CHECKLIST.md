# ✅ Kerkerker 自动化部署检查清单

## 🎯 部署前准备

### 必需资源
- [ ] Cloudflare 账户（免费即可）
- [ ] GitHub 仓库（存放项目代码）
- [ ] 自定义域名（可选，但推荐）

### 生成必需密钥
- [ ] **NEXTAUTH_SECRET**: 访问 https://generate-secret.vercel.app/32 生成32位随机字符串
- [ ] **ADMIN_EMAIL**: 您的管理员邮箱地址
- [ ] **ADMIN_PASSWORD**: 安全的管理员密码

## 🚀 Cloudflare Pages 部署

### 1. 创建 D1 数据库
- [ ] 登录 Cloudflare Dashboard
- [ ] 进入 "D1 SQL Database"
- [ ] 点击 "Create a database"
- [ ] 数据库名称: `kerkerker-db`
- [ ] **记录数据库 ID**（格式: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx）

### 2. 创建 Pages 项目
- [ ] 进入 "Pages" 服务
- [ ] 点击 "Create a project"
- [ ] 选择 "Connect to Git"
- [ ] 连接您的 GitHub 仓库
- [ ] 设置构建设置:
  - [ ] Build command: `npm run build`
  - [ ] Build output directory: `.next`
  - [ ] Root directory: `/`

### 3. 设置环境变量（仅需3个）
在项目设置中添加以下环境变量：

- [ ] **NEXTAUTH_SECRET**: `您生成的32位密钥`
- [ ] **ADMIN_EMAIL**: `您的管理员邮箱`
- [ ] **ADMIN_PASSWORD**: `您的管理员密码`

### 4. 绑定 D1 数据库
- [ ] 项目设置 → "Functions" → "D1 Database Bindings"
- [ ] 点击 "Add binding"
- [ ] Variable name: `DATABASE`
- [ ] Database: `kerkerker-db`
- [ ] Environment: 勾选 "Production" 和 "Preview"

### 5. 部署项目
- [ ] 点击 "Save and Deploy"
- [ ] 等待构建完成
- [ ] 记录部署的 URL（例如: `https://kerkerker-app.pages.dev`）

## 🔄 自动初始化验证

### 触发数据库初始化
- [ ] 首次访问部署的应用 URL
- [ ] 或手动访问: `https://your-domain.pages.dev/api/init-db`

### 验证初始化成功
- [ ] 访问健康检查: `https://your-domain.pages.dev/api/health`
- [ ] 确认返回状态为 `healthy`
- [ ] 确认数据库表数量 ≥ 4

### 管理员登录测试
- [ ] 访问应用首页
- [ ] 点击登录
- [ ] 使用设置的邮箱和密码登录
- [ ] 确认能成功进入管理界面

## 🏥 健康检查结果

### 正常状态示例
```json
{
  "status": "healthy",
  "database": {
    "status": "healthy",
    "connected": true,
    "tables": 10
  },
  "services": {
    "nextAuth": "healthy",
    "api": "healthy"
  }
}
```

### 可能的问题和解决方案

#### 问题1: 数据库未初始化
- **症状**: health 检查显示 tables = 0
- **解决**: 访问 `/api/init-db` 手动触发初始化

#### 问题2: D1 绑定失败
- **症状**: 数据库连接失败
- **解决**: 重新检查 D1 数据库绑定设置

#### 问题3: 环境变量错误
- **症状**: 认证失败或应用无法启动
- **解决**: 检查 NEXTAUTH_SECRET 和其他环境变量

## 🎉 部署成功确认

### 功能验证
- [ ] 首页正常加载
- [ ] 分类和标签显示正常
- [ ] 管理员登录成功
- [ ] 健康检查返回正常状态
- [ ] API 端点响应正常

### 性能验证
- [ ] 页面加载速度 < 3秒
- [ ] API 响应时间 < 1秒
- [ ] 数据库查询正常

## 📊 监控和维护

### 日常监控
- [ ] 定期访问 `/api/health` 检查状态
- [ ] 查看 Cloudflare Dashboard Analytics
- [ ] 监控 D1 数据库使用量

### 定期维护
- [ ] 检查备份状态
- [ ] 更新依赖包（通过 Git 自动更新）
- [ ] 监控存储使用量

## 🔧 故障排除

### 快速诊断
1. **检查环境变量**: Pages 项目设置中的 Environment Variables
2. **检查 D1 绑定**: Functions → D1 Database Bindings
3. **查看日志**: Pages 项目 → Functions → Logs
4. **健康检查**: 访问 `/api/health` 端点

### 常见错误修复
- **数据库初始化失败**: 重新触发 `/api/init-db`
- **权限问题**: 确认管理员邮箱和密码正确
- **构建失败**: 检查 package.json 和依赖配置

## 📞 紧急联系

### 故障恢复
- **回滚部署**: Pages 项目 → Deployments → 回滚到之前的版本
- **重置数据库**: D1 数据库 → Reset（谨慎操作）

### 数据备份
- **自动备份**: Cloudflare 自动备份 D1 数据
- **手动导出**: D1 数据库 → Export 数据

---

## 🎊 恭喜！

如果所有检查项目都通过，说明您的 Kerkerker 应用已经成功部署并正常运行！

### 下一步：
- 开始添加资源内容
- 自定义网站样式
- 配置用户注册（如果需要）
- 添加更多功能

**享受您的现代化云原生应用吧！** 🚀
