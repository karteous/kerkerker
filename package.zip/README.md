# Kerkerker - 自动化云部署版本

🌐 **完全自动化的 Cloudflare Pages + D1 部署，无需手动数据库操作**

## 🚀 一键部署

### 只需设置 3 个环境变量：

```bash
NEXTAUTH_SECRET=your-random-secret-key
ADMIN_EMAIL=admin@your-domain.com
ADMIN_PASSWORD=your-secure-password
```

### 自动完成：
- ✅ 数据库自动初始化
- ✅ 基础数据自动填充
- ✅ 默认管理员账户创建
- ✅ 分类和标签自动设置

## 📋 功能特性

### 🗄️ 数据库特性
- **完全自动化**: 无需手动 SQL 操作
- **智能初始化**: 首次访问自动完成数据库设置
- **健康监控**: 实时数据库状态检查
- **自动恢复**: 检测并修复数据库问题

### 🎯 应用特性
- **全球加速**: Cloudflare 全球 CDN
- **企业级数据库**: Cloudflare D1
- **自动备份**: 内置数据备份机制
- **高可用性**: 99.99% SLA 保证

### 🔒 安全特性
- **自动认证**: NextAuth.js 集成
- **密码加密**: 自动密码哈希处理
- **CORS 配置**: 自动安全头设置
- **环境隔离**: 开发/生产环境分离

## 🛠️ 部署步骤

### 1. 创建 D1 数据库
- Cloudflare Dashboard → D1 SQL Database
- 创建数据库，名称：`kerkerker-db`
- 记录数据库 ID

### 2. 设置环境变量
```bash
# 在 Pages 项目设置中添加：
NEXTAUTH_SECRET=your-32-char-secret
ADMIN_EMAIL=admin@your-domain.com  
ADMIN_PASSWORD=secure-password
```

### 3. 绑定 D1 数据库
- Pages 项目 → Functions → D1 Database Bindings
- 添加绑定：`DATABASE` → `kerkerker-db`

### 4. 访问应用
- 首次访问自动初始化数据库
- 默认管理员账户自动创建
- 访问 `/api/health` 验证部署

## 📊 数据库结构

### 核心表结构：
- **User**: 用户管理和认证
- **Resource**: 资源信息存储
- **Category**: 资源分类管理
- **Tag**: 标签系统
- **Comment**: 用户评论
- **SearchHistory**: 搜索记录
- **Settings**: 系统配置

### 自动初始数据：
- 5个默认分类（电影、音乐、软件、游戏、图书）
- 5个常用标签（热门、最新、高清、完整版、中文）
- 管理员账户
- 基础系统设置

## 🔧 管理接口

### API 端点：
- `GET /api/health` - 健康检查
- `POST /api/init-db` - 手动初始化数据库
- `GET /api/categories` - 获取分类列表
- `GET /api/tags` - 获取标签列表
- `GET /api/resources` - 获取资源列表

### 数据库管理：
- 通过 Prisma Studio: `npm run db:studio`
- 通过 Cloudflare Dashboard D1 查询界面
- 通过 API 进行程序化管理

## 🚀 开发命令

```bash
# 安装依赖
npm install

# 本地开发
npm run dev

# 构建项目
npm run build

# 数据库管理
npm run db:studio        # Prisma Studio
npm run db:generate      # 生成 Prisma 客户端
npm run db:push          # 推送架构更改

# 健康检查
npm run db:test:health   # 数据库健康检查
```

## 📈 监控和维护

### 自动监控：
- 数据库连接状态
- 应用健康状态
- 资源使用情况
- 错误日志收集

### 手动检查：
- Cloudflare Dashboard Analytics
- D1 数据库 Analytics
- Pages 项目日志
- Functions 执行日志

## 🔄 更新和维护

### 自动更新：
- 数据库架构版本控制
- 自动迁移脚本
- 数据完整性检查

### 手动维护：
- 定期备份检查
- 性能优化
- 安全更新

## 🎯 使用说明

### 管理员登录：
1. 访问应用首页
2. 使用设置的邮箱和密码登录
3. 即可开始管理资源

### 用户使用：
1. 浏览分类和标签
2. 搜索资源
3. 查看详情和评论

## 📞 支持

### 故障排除：
1. 检查 `/api/health` 返回状态
2. 查看 Cloudflare Dashboard 日志
3. 确认环境变量设置正确

### 技术支持：
- 详细文档：`AUTO_DEPLOY_GUIDE.md`
- API 文档：`/api/docs`（如启用）
- 日志分析：Cloudflare Dashboard

---

🎉 **现代化的云原生应用，享受企业级的性能和可靠性！**

**GitHub**: https://github.com/unilei/kerkerker  
**License**: MIT  
**Version**: 1.0.0
