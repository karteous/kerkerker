# Kerkerker Cloudflare 部署版本

这是一个为 Cloudflare Pages 优化的 Kerkerker 网盘资源搜索应用。

## 🚀 快速开始

### 方式一：直接部署到 Cloudflare Pages

1. **Fork 此仓库**
2. **连接 GitHub 到 Cloudflare Pages**
   - 登录 [Cloudflare Dashboard](https://dash.cloudflare.com)
   - 进入 Pages → 创建项目 → 连接 Git
   - 选择您 fork 的仓库

3. **配置构建设置**
   - Framework preset: `Next.js`
   - Build command: `npm run build`
   - Build output directory: `.next`
   - Node.js version: `18`

4. **设置环境变量**
   ```bash
   NODE_ENV=production
   NEXTAUTH_URL=https://your-subdomain.pages.dev
   NEXTAUTH_SECRET=your-32-character-secret
   DATABASE_URL=sqlite:./prisma/dev.db
   ```

5. **部署完成！**

### 方式二：本地开发和 Docker 部署

1. **克隆项目**
   ```bash
   git clone https://github.com/unilei/kerkerker.git
   cd kerkerker
   ```

2. **安装依赖**
   ```bash
   npm install
   ```

3. **复制环境变量**
   ```bash
   cp .env.template .env.local
   # 编辑 .env.local 填入实际值
   ```

4. **本地开发**
   ```bash
   npm run dev
   ```

5. **Docker 部署**
   ```bash
   docker-compose up -d
   ```

## 📁 项目结构

```
├── app/                    # Next.js 13+ App Router
│   ├── api/               # API 路由
│   │   └── health/        # 健康检查端点
│   └── globals.css        # 全局样式
├── components/            # React 组件
├── hooks/                # 自定义 hooks
├── lib/                  # 工具函数
├── prisma/               # 数据库配置
├── types/                # TypeScript 类型
├── .env.template         # 环境变量模板
├── cloudflare.json       # Cloudflare 配置
├── wrangler.toml        # Cloudflare Pages 配置
├── Dockerfile           # Docker 配置
├── docker-compose.yml   # Docker Compose 配置
├── next.config.mjs      # Next.js 配置（Cloudflare 优化）
└── CLOUDFLARE_DEPLOY.md # 详细部署指南
```

## ⚙️ Cloudflare 特性

### 🚀 性能优化
- **全球 CDN**: Cloudflare 全球网络加速
- **Edge Network**: 就近访问，延迟更低
- **自动压缩**: gzip/brotli 压缩
- **智能缓存**: 静态资源缓存策略

### 🔒 安全特性
- **自动 HTTPS**: SSL/TLS 加密
- **WAF 保护**: Web 应用防火墙
- **DDoS 防护**: 分布式拒绝服务攻击防护
- **安全头**: XSS、CSRF 保护

### 📊 监控分析
- **实时分析**: 访问量、性能监控
- **错误追踪**: 实时错误日志
- **Core Web Vitals**: 性能指标监控

## 🛠️ 配置说明

### 环境变量

| 变量名 | 描述 | 必需 | 默认值 |
|--------|------|------|--------|
| `NODE_ENV` | 运行环境 | 是 | `production` |
| `NEXTAUTH_URL` | 应用 URL | 是 | - |
| `NEXTAUTH_SECRET` | NextAuth 密钥 | 是 | - |
| `DATABASE_URL` | 数据库连接字符串 | 是 | - |

### Cloudflare 配置

#### `wrangler.toml`
```toml
[env.production.vars]
NODE_ENV = "production"
NEXTAUTH_URL = "https://your-domain.pages.dev"
NEXTAUTH_SECRET = "your-secret"
```

#### `cloudflare.json`
```json
{
  "builds": [
    {
      "src": "next.config.mjs",
      "use": "@cloudflare/next-on-pages"
    }
  ]
}
```

## 📚 数据库选项

### SQLite（开发环境）
```bash
DATABASE_URL="sqlite:./prisma/dev.db"
```

### Cloudflare D1（生产环境）
```bash
# 创建 D1 数据库
wrangler d1 create kerkerker-db

# 在 wrangler.toml 中配置
[env.production.d1_databases]
DATABASE = { 
  binding = "DATABASE", 
  database_name = "kerkerker-db", 
  database_id = "your-db-id" 
}

# 设置环境变量
DATABASE_URL="sqlite:./prisma/prod.db"
```

## 🔧 开发命令

```bash
# 开发环境
npm run dev

# 构建生产版本
npm run build

# 启动生产服务器
npm run start

# 数据库操作
npm run db:generate  # 生成 Prisma 客户端
npm run db:push      # 推送数据库模式
npm run db:studio    # 打开 Prisma Studio

# 代码质量
npm run lint         # ESLint 检查
npm run type-check   # TypeScript 类型检查
npm run format       # 代码格式化
```

## 🐳 Docker 部署

### 单容器部署
```bash
# 构建镜像
docker build -t kerkerker-app .

# 运行容器
docker run -p 3000:3000 --env-file .env.local kerkerker-app
```

### 完整栈部署
```bash
# 启动所有服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

## 📈 监控和维护

### 部署状态监控
- Cloudflare Dashboard → Pages → 您的项目
- 查看构建日志、函数日志、访问统计

### 性能监控
- **Cloudflare Analytics**: 访问量和性能数据
- **Core Web Vitals**: 核心性能指标
- **错误监控**: 实时错误报告

### 更新部署
```bash
# Git 部署（推荐）
git push origin main  # 自动触发部署

# 手动部署
wrangler pages deploy .next --project-name=kerkerker-app
```

## 🚨 故障排除

### 常见问题

1. **构建失败**
   - 检查 Node.js 版本（需要 >= 18）
   - 验证环境变量配置
   - 查看详细构建日志

2. **数据库连接错误**
   - 确认 DATABASE_URL 格式正确
   - 检查数据库文件权限

3. **页面加载问题**
   - 验证域名配置
   - 检查路由设置

### 调试步骤

1. **本地测试**
   ```bash
   npm run build
   npm run start
   ```

2. **查看日志**
   - Cloudflare Dashboard → Pages → Functions
   - 实时运行时日志

3. **环境变量检查**
   - 在 Cloudflare Dashboard 中验证所有必需变量

## 📄 许可证

ISC License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📞 支持

- 查看 [CLOUDFLARE_DEPLOY.md](./CLOUDFLARE_DEPLOY.md) 获取详细部署指南
- 访问 [Cloudflare 文档](https://developers.cloudflare.com/pages/)
- 提交 GitHub Issue

---

**享受在 Cloudflare 上的极速体验！** ⚡️