/**
 * Next.js 应用启动文件
 * 在应用启动时自动初始化数据库
 */

import { initApp } from '../lib/init-db.js';

// 全局变量，标记应用是否已初始化
let appInitialized = false;

/**
 * 应用启动时的初始化函数
 */
async function initializeApp() {
  if (appInitialized) {
    return true;
  }
  
  try {
    console.log('🚀 启动 Kerkerker 应用...');
    
    // 初始化数据库和应用
    const success = await initApp();
    
    if (success) {
      appInitialized = true;
      console.log('✅ 应用启动完成');
      return true;
    } else {
      console.error('❌ 应用启动失败');
      return false;
    }
  } catch (error) {
    console.error('❌ 应用初始化错误:', error);
    return false;
  }
}

// 开发环境下的初始化
if (process.env.NODE_ENV === 'development') {
  // 在开发环境中立即初始化
  initializeApp().catch(error => {
    console.error('开发环境初始化失败:', error);
  });
}

/**
 * Next.js 配置优化
 */
const nextConfig = {
  // 启用实验性特性
  experimental: {
    serverComponentsExternalPackages: ['@prisma/client', 'prisma'],
  },
  
  // 图片配置
  images: {
    domains: ['images.unsplash.com', 'via.placeholder.com'],
    formats: ['image/webp', 'image/avif'],
  },
  
  // 编译优化
  compiler: {
    // 移除console.log等调试代码
    removeConsole: process.env.NODE_ENV === 'production',
  },
  
  // 构建输出配置
  output: 'standalone',
  
  // 环境变量
  env: {
    APP_TITLE: 'Kerkerker',
    APP_DESCRIPTION: '网盘资源搜索神器',
    APP_VERSION: '1.0.0',
  },
  
  // Cloudflare Pages 优化配置
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: '/api/:path*',
      },
    ];
  },
  
  // 安全配置
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ];
  },
  
  // 性能优化
  webpack: (config, { buildId, dev, isServer, defaultLoaders, webpack }) => {
    // 生产环境优化
    if (!dev && !isServer) {
      config.optimization.splitChunks = {
        chunks: 'all',
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name: 'vendors',
            chunks: 'all',
          },
        },
      };
    }
    
    return config;
  },
};

export default nextConfig;
