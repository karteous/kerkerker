# Kerkerker Cloudflare Pages 部署指南

## 项目概述

本项目已适配Cloudflare Pages部署，包含完整的配置和部署流程。

## 部署方式

### 方式一：通过 Git 仓库自动部署（推荐）

1. **Fork/Clone 项目到您的 GitHub 仓库**

2. **在 Cloudflare Dashboard 创建 Pages 项目**
   - 登录 [Cloudflare Dashboard](https://dash.cloudflare.com)
   - 进入 "Pages" 页面
   - 点击 "Create a project"
   - 选择 "Connect to Git"
   - 授权 GitHub 访问权限
   - 选择您的仓库

3. **配置构建设置**
   - Framework preset: `Next.js`
   - Build command: `npm run build`
   - Build output directory: `.next`
   - Node.js version: `18`

4. **设置环境变量**
   ```
   NODE_ENV=production
   NEXTAUTH_URL=https://your-subdomain.pages.dev
   NEXTAUTH_SECRET=your-secure-random-string
   DATABASE_URL=sqlite:./prisma/dev.db
   ```

5. **部署项目**
   - 点击 "Save and Deploy"
   - 等待构建完成（通常需要 2-5 分钟）

### 方式二：通过 wrangler CLI 部署

1. **安装 Wrangler CLI**
   ```bash
   npm install -g wrangler
   ```

2. **登录 Cloudflare**
   ```bash
   wrangler login
   ```

3. **初始化项目**
   ```bash
   wrangler pages project create kerkerker-app
   ```

4. **部署项目**
   ```bash
   wrangler pages deploy .next --project-name=kerkerker-app
   ```

## 数据库配置

### 选项 1: 使用 SQLite（本地开发推荐）
```prisma
// prisma/schema.prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}
```

### 选项 2: 使用 Cloudflare D1（生产环境推荐）
```prisma
// prisma/schema.prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "sqlite"
  url      = env("DATABASE_URL")
}
```

```bash
# 创建 D1 数据库
wrangler d1 create kerkerker-db

# 配置 wrangler.toml
[env.production.d1_databases]
DATABASE = { binding = "DATABASE", database_name = "kerkerker-db", database_id = "your-db-id" }

# 运行数据库迁移
wrangler d1 execute kerkerker-db --file=./prisma/migrations/your_migration.sql
```

## 环境变量配置

### 必需的环境变量
```bash
NODE_ENV=production
NEXTAUTH_URL=https://your-subdomain.pages.dev
NEXTAUTH_SECRET=your-32-character-secret
DATABASE_URL=sqlite:./prisma/dev.db
```

### 可选的环境变量
```bash
TELEGRAM_BOT_TOKEN=your-telegram-bot-token
HTTP_PROXY=your-proxy-server
ADMIN_EMAIL=admin@example.com
ADMIN_PASSWORD=your-admin-password
```

## API 路由处理

项目包含 API 路由，Cloudflare Pages 会自动处理：
- `/api/*` - API 端点
- `/auth/*` - NextAuth 认证端点

## 性能优化

### 1. 启用静态资源缓存
Cloudflare Pages 自动提供：
- 全球 CDN 分发
- 自动压缩 (gzip/brotli)
- 静态资源缓存

### 2. 图片优化
```javascript
// next.config.mjs 已配置
images: {
  formats: ['image/avif', 'image/webp'],
  deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
}
```

### 3. 路由优化
- 使用 Edge Network 加速
- 支持全球负载均衡
- 自动 HTTPS 重定向

## 自定义域名配置

1. **添加自定义域名**
   - 在 Pages 项目设置中
   - 点击 "Custom domains"
   - 添加您的域名

2. **配置 DNS**
   - 添加 CNAME 记录指向您的 Pages 项目
   - 例如：`kerkerker.yourdomain.com CNAME your-app.pages.dev`

3. **SSL 证书**
   - Cloudflare 自动提供 SSL 证书
   - 无需额外配置

## 监控和日志

### 查看构建日志
1. 在 Cloudflare Dashboard 中
2. 进入您的 Pages 项目
3. 查看 "Functions" 和 "Builds" 标签

### 错误处理
- Cloudflare Pages 提供详细的错误日志
- 支持实时错误监控
- 自动错误报告

## 故障排除

### 常见问题

1. **构建失败**
   - 检查 Node.js 版本是否 >= 18
   - 验证 package.json 中的依赖
   - 查看构建日志中的具体错误

2. **数据库连接问题**
   - 确保 DATABASE_URL 格式正确
   - 检查数据库文件路径权限

3. **API 路由问题**
   - 验证 API 路由代码兼容性
   - 检查环境变量配置

4. **页面加载问题**
   - 验证路由配置
   - 检查 Next.js 配置兼容性

### 调试步骤

1. **本地开发测试**
   ```bash
   npm install
   npm run dev
   ```

2. **本地构建测试**
   ```bash
   npm run build
   npm run start
   ```

3. **查看详细日志**
   - Cloudflare Dashboard > Pages > 您的项目 > Functions
   - 查看 Runtime logs

## 更新部署

### 自动更新（Git 部署）
- 推送到主分支自动触发重新部署
- 支持预览部署（pull request 时）

### 手动更新
```bash
# 通过 wrangler CLI 重新部署
wrangler pages deploy .next --project-name=kerkerker-app
```

## 备份策略

1. **代码备份**
   - Git 仓库自动备份

2. **数据库备份**
   ```bash
   # 导出 D1 数据库
   wrangler d1 export kerkerker-db --output=backup.sql
   
   # 导入数据库
   wrangler d1 execute kerkerker-db --file=backup.sql
   ```

## 性能监控

1. **Cloudflare Analytics**
   - 访问量统计
   - 性能指标监控

2. **Core Web Vitals**
   - 自动监控和报告
   - 实时性能数据

## 安全配置

1. **环境变量保护**
   - 在 Cloudflare Dashboard 中安全存储
   - 不在代码中暴露敏感信息

2. **HTTPS 强制**
   - Cloudflare 自动提供 SSL
   - 支持 HTTPS 强制重定向

3. **安全头配置**
   - X-Content-Type-Options
   - X-Frame-Options
   - X-XSS-Protection

## 成本优化

1. **请求数量限制**
   - Cloudflare Pages 提供免费配额
   - 超额部分按请求计费

2. **带宽优化**
   - 自动压缩和缓存
   - 全球 CDN 减少延迟

## 技术支持

如需技术支持，请：
1. 查看 Cloudflare 官方文档
2. 提交 GitHub Issue
3. 访问社区论坛

---

**部署成功后，您的 Kerkerker 应用将在全球范围内提供快速、可靠的服务！**